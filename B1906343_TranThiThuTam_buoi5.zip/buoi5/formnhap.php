<!DOCTYPE HTML>
<html>  
<body>

<form action="luu.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Birthday: <input type="date" name="birth"><br>
Password: <input type="password" name="pass"><br>

<input type="submit">
</form>

</body>
</html>
